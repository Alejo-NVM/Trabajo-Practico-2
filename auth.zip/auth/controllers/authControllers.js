const sql = require("mssql");
const bcrypt = require("bcrypt");
const speakeasy = require("speakeasy");
const qrcode = require("qrcode");
const qrcodeTerminal = require("qrcode-terminal"); // <--- agregado
const { poolPromise } = require("../../config/db.js");
const { generarSugerencias } = require("../utils/generarSugerencias.js");

async function registrarUsuario(req, res) {
  const { username, password, role } = req.body;
  if (!username || !password || !role)
    return res.status(400).json({ message: "Faltan datos" });

  try {
    const pool = await poolPromise;

    // Verificar si ya existe
    const userExist = await pool
      .request()
      .input("usuario", sql.NVarChar, username)
      .query("SELECT * FROM Usuarios WHERE usuario = @usuario");

    if (userExist.recordset.length > 0) {
      const sugerencias = generarSugerencias(username);
      return res.status(409).json({
        message: "Nombre de usuario ocupado. ¿No prefiere uno de estos?",
        sugerencias,
      });
    }

    // Hash de password
    const passwordHash = await bcrypt.hash(password, 10);

    // Generar secreto TOTP
    const secret = speakeasy.generateSecret({
      name: `GestionEventos (${username})`,
    });

    // Guardar usuario
    await pool
      .request()
      .input("usuario", sql.NVarChar, username)
      .input("passwordHash", sql.NVarChar, passwordHash)
      .input("rol", sql.NVarChar, role)
      .input("totpSecret", sql.NVarChar, secret.base32)
      .query(
        "INSERT INTO Usuarios (usuario, passwordHash, rol, totpSecret) VALUES (@usuario, @passwordHash, @rol, @totpSecret)"
      );

    // Mostrar QR en consola ASCII
    qrcodeTerminal.generate(secret.otpauth_url, { small: true }, (qr) => {
      console.log("Escaneá este código QR con una app autenticadora:");
      console.log(qr);
    });

    // Para Postman y frontend
    const qrDataUrl = await qrcode.toDataURL(secret.otpauth_url);

    res.json({
      message: "Usuario registrado",
      qr: qrDataUrl,
      instrucciones:
        "Escaneá este código QR con una app de autenticación (Google Authenticator, Authy, etc.) para configurar tu TOTP.",
      otpauthUrl: secret.otpauth_url,
    });
  } catch (err) {
    console.error("Error en /register:", err);
    res.status(500).json({ message: "Error interno del servidor" });
  }
}

module.exports = { registrarUsuario };
