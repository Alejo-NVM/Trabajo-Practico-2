require("dotenv").config();
const express = require("express");
const morgan = require("morgan");
const app = express();
const port = process.env.PORT || 4000;

const authRoutes = require("./auth/routes/authRoutes");

// Middlewares
app.use(morgan("dev"));
app.use(express.json());

// Rutas
app.use("/auth", authRoutes);

app.listen(port, () => {
  console.log(`🚀 Servidor corriendo en puerto ${port}`);
});
