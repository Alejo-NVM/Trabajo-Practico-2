const express = require("express");
const router = express.Router();
const { poolPromise, sql } = require("../config/db");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const speakeasy = require("speakeasy");
const qrcode = require("qrcode");

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRATION = process.env.JWT_EXPIRATION || "1h";
const REFRESH_SECRET = process.env.REFRESH_SECRET;
const REFRESH_EXPIRATION = process.env.REFRESH_EXPIRATION || "1d";

// Registro inicial con hash y generación secreto TOTP
router.post("/register", async (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password || !role)
    return res.status(400).json({ message: "Faltan datos" });

  try {
    const pool = await poolPromise;

    // Verificar usuario existente
    const userExist = await pool
      .request()
      .input("username", sql.NVarChar, username)
      .query("SELECT * FROM Users WHERE Username = @username");
    if (userExist.recordset.length > 0)
      return res.status(400).json({ message: "Usuario ya existe" });

    // Hash de password
    const passwordHash = await bcrypt.hash(password, 10);

    // Generar secreto TOTP
    const secret = speakeasy.generateSecret({
      name: `GestionEventos (${username})`,
    });

    // Guardar usuario
    await pool
      .request()
      .input("username", sql.NVarChar, username)
      .input("passwordHash", sql.NVarChar, passwordHash)
      .input("role", sql.NVarChar, role)
      .input("totpSecret", sql.NVarChar, secret.base32)
      .query(
        "INSERT INTO Users (Username, PasswordHash, Role, TotpSecret) VALUES (@username, @passwordHash, @role, @totpSecret)"
      );

    // Generar QR para TOTP
    const otpauthUrl = secret.otpauth_url;
    const qrDataUrl = await qrcode.toDataURL(otpauthUrl);

    res.json({ message: "Usuario registrado", qr: qrDataUrl, otpauthUrl });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error interno" });
  }
});

// Login con password y código TOTP
router.post("/login", async (req, res) => {
  const { username, password, totpCode } = req.body;
  if (!username || !password || !totpCode)
    return res.status(400).json({ message: "Faltan datos" });

  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("username", sql.NVarChar, username)
      .query("SELECT * FROM Users WHERE Username = @username");

    if (result.recordset.length === 0)
      return res.status(400).json({ message: "Usuario no encontrado" });

    const user = result.recordset[0];

    // Verificar password
    const validPass = await bcrypt.compare(password, user.PasswordHash);
    if (!validPass)
      return res.status(401).json({ message: "Password incorrecta" });

    // Verificar código TOTP
    const verified = speakeasy.totp.verify({
      secret: user.TotpSecret,
      encoding: "base32",
      token: totpCode,
      window: 1,
    });

    if (!verified)
      return res.status(401).json({ message: "Código TOTP inválido" });

    // Generar JWT y refresh token
    const payload = { id: user.Id, username: user.Username, role: user.Role };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRATION });
    const refreshToken = jwt.sign(payload, REFRESH_SECRET, {
      expiresIn: REFRESH_EXPIRATION,
    });

    res.json({ token, refreshToken });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error interno" });
  }
});

// Endpoint para refrescar JWT
router.post("/refresh", (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ message: "Faltan datos" });

  try {
    const payload = jwt.verify(refreshToken, REFRESH_SECRET);
    const token = jwt.sign(
      { id: payload.id, username: payload.username, role: payload.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRATION }
    );
    res.json({ token });
  } catch (err) {
    console.error(err);
    return res
      .status(401)
      .json({ message: "Refresh token inválido o expirado" });
  }
});

module.exports = router;
